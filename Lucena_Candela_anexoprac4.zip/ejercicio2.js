window.onload = function(){
  var enlace = document.getElementById("enlace");
  enlace.addEventListener("click", parar);
}
    
function parar(event){
    event.preventDefault();
}
