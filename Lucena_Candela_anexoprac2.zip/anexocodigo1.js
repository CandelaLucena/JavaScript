//Candela Lucena
function alerta(){
    alert("Esto es un hiperenlace!");
}