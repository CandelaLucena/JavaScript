//Candela Lucena campo de texto

var valor = 0;
var resultado = document.getElementById("resultado");

function sumar(){
   valor = valor + 10;
   resultado.innerHTML = valor;
}
function ponerValorCero(){
    valor = 0;
    resultado.innerHTML = valor;
}

