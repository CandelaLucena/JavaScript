//Candela Lucena
var cadena = "2+2";
/*function eval(cadena){
    cadenaArray = cadena.split('');
    valor1 = parseInt(cadenaArray[0]);
    valor2 = parseInt(cadenaArray[2]);
    
    valor3 = cadenaArray[1];
    alert(valor1+valor2);
}

eval(cadena);*/
document.write(eval(cadena));