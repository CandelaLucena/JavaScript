$(document).ready(function(){
    alert("Tamaño: " + $( "div" ).length);
    $("div").css("background-color", "green");
})
