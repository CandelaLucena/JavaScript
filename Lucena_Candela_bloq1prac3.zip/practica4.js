function contarImagenes(){
    var imagenes = document.getElementsByTagName("a");  
    alert(imagenes.length);
}

function contarEnlaces(){
    var enlaces = document.getElementsByTagName("img");  
    alert(enlaces.length);
}