var parrafo = document.getElementById("uno");
parrafo.setAttribute("name", "parrafoNumeroUno");
alert(parrafo);