var div = document.getElementById("divisor");

function colorRojo(){
    div.style.backgroundColor = "red";
}
function colorVerde(){
    div.style.backgroundColor = "green";
}
function colorAzul() {
    div.style.backgroundColor = "blue";
}
function colorWhite() {
    div.style.backgroundColor = "white";
}
/*
var rojo = document.getElementById("rojo");
rojo.addEventListener("click",colorRojo);
var verde = document.getElementById("verde");
verde.addEventListener("click",colorVerde);
var azul = document.getElementById("azul");
azul.addEventListener("click",colorAzul);
*/
