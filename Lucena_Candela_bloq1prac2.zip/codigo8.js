//Candela Lucena
function abrirGoogle(){
    window.open("https://www.google.com/");
}
var URLactual = window.location;
document.write(URLactual+"<br>");

var pathname = window.location.pathname;
document.write(pathname+"<br>");

var protocol = window.location.protocol;
document.write(protocol+"<br>");