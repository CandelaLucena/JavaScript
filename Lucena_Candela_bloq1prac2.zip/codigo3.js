//Candela Lucena Reyes
document.write("<h1>Bienvenido a mi página</h1>");
var nombreNavegador = navigator.userAgent;
if(confirm(nombreNavegador)==true){
    document.write("continuemos");
}else{
    document.write("error")
}


