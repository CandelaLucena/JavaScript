//Candela Lucena
function colorRojo(){
    document.body.style.backgroundColor = "red";
}
function colorVerde(){
    document.body.style.backgroundColor = "green";
}
function colorAzul(){
    document.body.style.backgroundColor = "blue";
}