//Candela Lucena Reyes
var numero = parseInt (prompt("Dime un numero",""));

if (numero%2==0){
    alert("Es par");
}else{
    alert("Es inpar");
}