function resaltaGrande(elemento){
    elemento.style.fontSize = "20pt";
}
function resaltaPequenyo(elemento){
    elemento.style.fontSize = "10pt";
}

/*
function resalta(elemento){
    var evento = elemento.event || window.event;
    switch(evento.type) {
        case "mouseover":
            elemento.style.fontSize = "20pt";
            break;
        case "mouseout":
            elemento.style.fontSize = "10pt";
            break;
    }
}
*/